<?php

/*
 * Plugin Name: Shafa Example Plugin
 */

 // Remove the admin bar from the front end
add_filter( 'show_admin_bar', '__return_false' );
